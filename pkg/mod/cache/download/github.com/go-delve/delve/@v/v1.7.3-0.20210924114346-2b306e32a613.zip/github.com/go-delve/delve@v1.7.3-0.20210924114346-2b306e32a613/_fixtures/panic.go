package main

func main() {
	msg := "BOOM!"
	panic(msg)
}
